c_code {
	if(now.cost < min_cost) {
		min_cost = now.cost;
	}
}