extern const int p0; enum msg_type { Msg, Ack, TimeOut };

void handshake(void) {
	send(p0, Msg);
	set_timer(16000); /* msec */
	int resp = wait_recv();
	switch (resp) {
	case Ack:     reset_timer(); break;
	case TimeOut: /* handle */ break;
	default: reset_timer(); error("meh"); break;
	}
}
